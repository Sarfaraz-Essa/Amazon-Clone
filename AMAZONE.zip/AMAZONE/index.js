const scrollContaainer= document.querySelectorAll('.products');
for(const item of scrollContaainer){
    item.addEventListener('wheel',(evt) =>{
        evt.preventDefault();
        item.scrollLeft += evt.deltaY;
    })
}